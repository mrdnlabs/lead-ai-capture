// screens.jsx — every screen of red5 / capture
// Each screen is a component rendered inside a fixed-size iPhone frame (390×844 content).
// Uses globals from ui.jsx.

// ──────────────────────────────────────────────────────────────
// 01 · Sign in
// ──────────────────────────────────────────────────────────────
function SignInScreen({ email = '', onChangeEmail, onSubmit, sent = false }) {
  return (
    <div className="scr">
      <TopBar left={<BrandMark />} right={null} />
      <div className="scr-body" style={{ justifyContent: 'center', paddingBottom: 60 }}>
        <div style={{ marginTop: 24 }}>
          <div className="t-eyebrow">Sign in</div>
          <h1 className="t-title-lg" style={{ marginTop: 8 }}>Ready when you are.</h1>
          <p className="t-body mt-12" style={{ maxWidth: 320 }}>
            Magic-link sign in. One tap from your inbox and you're back at the booth.
          </p>
        </div>

        <div className="col" style={{ gap: 12, marginTop: 32 }}>
          <label className="t-tiny" style={{ fontWeight: 600, color: 'var(--ink-3)' }}>
            EMAIL
          </label>
          <input
            className="input"
            type="email"
            placeholder="riley@yourcompany.com"
            value={email}
            onChange={(e) => onChangeEmail?.(e.target.value)}
          />
          <button className="btn btn-primary btn-block" onClick={onSubmit}>
            {sent ? 'Link sent — check your inbox' : 'Email me a link'}
            {!sent && <Ic.Arrow size={18} />}
          </button>
        </div>

        {sent && (
          <div className="card-flat mt-16" style={{ borderLeft: '3px solid var(--accent)' }}>
            <div className="t-meta" style={{ color: 'var(--ink-2)' }}>
              We sent a sign-in link to <strong>{email || 'your inbox'}</strong>. Tap it on this phone.
            </div>
          </div>
        )}
      </div>
      <div className="scr-foot" style={{ textAlign: 'center' }}>
        <div className="brand-sm">
          Published by <span className="b-strong">red5</span>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 02 · Home — list of shows the rep belongs to
// ──────────────────────────────────────────────────────────────
function HomeScreen({ onOpen, queue = 0, rep = 'riley@yourcompany.com' }) {
  const shows = [
    { code: 'TS26', name: 'Tech Summit 2026', when: 'Today · Hall B', leads: 38, badge: 'TS', live: true },
    { code: 'RNX', name: 'Robotics Expo NYC',  when: 'Apr 14–16',     leads: 124, badge: 'RX', live: false, swatch: 'alt-1' },
    { code: 'DEV',  name: 'DevWorld London',    when: 'May 02–04',     leads: 0,   badge: 'DW', live: false, swatch: 'alt-2' },
  ];
  return (
    <div className="scr">
      <TopBar
        left={<BrandMark />}
        right={<QueuePill count={queue} />}
      />
      <div className="scr-body">
        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
          <div>
            <div className="t-eyebrow">Signed in</div>
            <div className="t-body mt-4" style={{ fontWeight: 500, color: 'var(--ink)' }}>{rep}</div>
          </div>
        </div>

        <Section label="Your shows" right={
          <button className="btn btn-sm btn-ghost"><Ic.QR size={14}/> Join</button>
        }>
          <div className="col" style={{ gap: 10 }}>
            {shows.map((s) => (
              <div key={s.code} className="show-card" onClick={() => onOpen?.(s.code)}>
                <div className={`swatch ${s.swatch || ''}`}>{s.badge}</div>
                <div className="meta">
                  <div className="name">{s.name}</div>
                  <div className="sub">
                    <span className="op-code" style={{ color: 'var(--ink-2)' }}>{s.code}</span>
                    <span style={{ margin: '0 6px', color: 'var(--ink-5)' }}>·</span>
                    {s.when}
                    <span style={{ margin: '0 6px', color: 'var(--ink-5)' }}>·</span>
                    {s.leads} leads
                  </div>
                </div>
                {s.live ? <LivePill label="today" /> : <Ic.Chev size={16} color="var(--ink-4)" />}
              </div>
            ))}
          </div>
        </Section>

        <div className="spacer" />

        <div className="card-flat mt-24" style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'var(--accent-wash)', color: 'var(--accent)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Ic.Sparkle size={18} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 500, fontSize: 13 }}>Hold your phone vertically</div>
            <div className="t-tiny mt-4">Capture is built for one hand. The big button is always in thumb reach.</div>
          </div>
        </div>
      </div>
      <div className="scr-foot" style={{ textAlign: 'center' }}>
        <div className="brand-sm">Published by <span className="b-strong">red5</span></div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 03 · Capture — Ready (idle, before recording). Now the app's home.
// ──────────────────────────────────────────────────────────────
function CaptureReadyScreen({
  onStart, queue = 0, syncing = 0, onQueueTap,
  show = { badge: 'TS', name: 'Tech Summit 2026', swatch: '' },
  onSwitchShow, onPickLead, onClearTarget,
  targetLead = null, // { name, code }
}) {
  const [aiAssist, setAiAssist] = useState(true);
  return (
    <div className="scr">
      <TopBar
        left={
          <button className="show-pill" onClick={onSwitchShow}>
            <span className={`swatch-xs ${show.swatch || ''}`}>{show.badge}</span>
            <span className="nm">{show.name}</span>
            <Ic.Chev size={14} color="var(--ink-4)" style={{ transform: 'rotate(90deg)' }} />
          </button>
        }
        right={<QueuePill count={queue} syncing={syncing} onClick={onQueueTap} />}
      />
      <div className="scr-body">
        <div>
          <div className="t-eyebrow">New capture</div>
          <h1 className="t-title" style={{ marginTop: 6 }}>
            {targetLead ? `Adding to ${targetLead.name}` : 'Ready when you are.'}
          </h1>
        </div>

        {targetLead && (
          <div className="target-chip mt-16">
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'rgba(255,255,255,0.18)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Ic.User size={18} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="row" style={{ gap: 8, alignItems: 'baseline' }}>
                <span className="lbl">Updating</span>
                <span className="code-on-accent">{targetLead.code}</span>
              </div>
              <div className="nm" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginTop: 1 }}>
                {targetLead.name}
              </div>
            </div>
            <button className="close" onClick={onClearTarget} aria-label="Clear target">
              <Ic.X size={14} />
            </button>
          </div>
        )}

        <div className="card mt-16" style={{ padding: 0, overflow: 'hidden' }}>
          <div className="photo-thumb" style={{ borderRadius: 0, aspectRatio: '16/10', border: 'none' }}>
            BADGE PHOTO — TAP CAMERA
          </div>
          <div className="row" style={{ padding: 12, gap: 8 }}>
            <button className="icon-btn" style={{ flex: 1 }}>
              <Ic.Camera size={18} />
              <span style={{ marginLeft: 8, fontSize: 13, fontWeight: 500 }}>Camera</span>
            </button>
            <button className="icon-btn" style={{ flex: 1 }}>
              <Ic.Image size={18} />
              <span style={{ marginLeft: 8, fontSize: 13, fontWeight: 500 }}>Library</span>
            </button>
          </div>
        </div>

        <div
          className="card mt-12"
          style={{
            display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer',
            borderColor: aiAssist ? 'var(--ink)' : 'var(--rule)',
          }}
          onClick={() => setAiAssist(!aiAssist)}
        >
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: aiAssist ? 'var(--ink)' : 'var(--paper-2)',
            color: aiAssist ? 'var(--paper)' : 'var(--ink-3)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Ic.Sparkle size={18} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 14 }}>AI assist</div>
            <div className="t-tiny mt-4">Asks short gap-filling questions while you talk.</div>
          </div>
          <Toggle on={aiAssist} />
        </div>

        {!targetLead && (
          <button
            className="card-flat mt-12"
            onClick={onPickLead}
            style={{
              display: 'flex', alignItems: 'center', gap: 12,
              border: 0, font: 'inherit', color: 'inherit',
              cursor: 'pointer', textAlign: 'left', width: '100%',
            }}
          >
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'var(--paper-3)', color: 'var(--ink-2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Ic.User size={18} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Continue with an existing lead</div>
              <div className="t-tiny mt-4">Skip the match — pick a lead to add this capture to.</div>
            </div>
            <Ic.Chev size={16} color="var(--ink-4)" />
          </button>
        )}

        <div className="spacer" />
      </div>
      <div className="scr-foot">
        <button className="cap-btn" onClick={onStart}>
          <span className="cap-ring" />
          {targetLead ? `Tap to add to ${targetLead.code}` : 'Tap to capture'}
        </button>
        <div className="t-tiny mt-12" style={{ textAlign: 'center', color: 'var(--ink-4)' }}>
          Audio always saved · offline-ready
        </div>
      </div>
    </div>
  );
}

// Small toggle
function Toggle({ on }) {
  return (
    <div style={{
      width: 38, height: 22, borderRadius: 11,
      background: on ? 'var(--ink)' : 'var(--paper-3)',
      position: 'relative',
      transition: 'background 0.18s ease',
      flexShrink: 0,
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 18 : 2,
        width: 18, height: 18, borderRadius: '50%', background: 'var(--surface)',
        boxShadow: '0 1px 2px rgba(0,0,0,0.2)',
        transition: 'left 0.18s ease',
      }} />
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 04 · Capture — LIVE (recording, AI active, match banner, checklist)
// ──────────────────────────────────────────────────────────────
function CaptureLiveScreen({ elapsed = 18, onStop, showName = 'Tech Summit 2026', match = true, code = 'ABC-742' }) {
  const checks = [
    { label: 'Name',    value: 'David Chen',     done: true },
    { label: 'Company', value: 'Acme Robotics',  done: true },
    { label: 'Title',   value: 'VP Engineering', done: true },
    { label: 'Email',   value: 'd.chen@acme.io', done: true },
    { label: 'Interest',value: null,             done: false },
    { label: 'Phone',   value: null,             done: false },
  ];
  const transcript = [
    { who: 'AI',  text: 'Got it — David Chen, Acme Robotics. Interest level?', role: 'ai' },
    { who: 'You', text: 'High. Scoping a pilot for Q3.', role: 'rep' },
    { who: 'AI',  text: 'Best email or phone to follow up?', role: 'ai' },
  ];
  const mm = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const ss = String(elapsed % 60).padStart(2, '0');
  return (
    <div className="scr">
      <TopBar
        left={<div className="t-eyebrow" style={{ whiteSpace: 'nowrap' }}>{showName}</div>}
        right={
          <div className="row gap-8">
            <span className="pill pill-live">
              <span className="dot" />
              <span style={{ fontVariantNumeric: 'tabular-nums' }}>{mm}:{ss}</span>
            </span>
          </div>
        }
      />
      <div className="scr-body" style={{ paddingTop: 4 }}>
        {match && (
          <div className="match-banner">
            <div style={{
              width: 38, height: 38, borderRadius: 10,
              background: 'var(--accent)', color: 'var(--accent-ink)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              flexShrink: 0,
            }}>
              <Ic.Sparkle size={18} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="label">Returning lead</div>
              <div className="who" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                David Chen <span className="code" style={{ marginLeft: 6 }}>{code}</span>
              </div>
            </div>
            <button style={{
              flexShrink: 0, height: 28, padding: '0 10px', borderRadius: 8, fontSize: 12,
              fontWeight: 500, fontFamily: 'inherit', cursor: 'pointer', whiteSpace: 'nowrap',
              border: '1px solid var(--rule-2)', background: 'var(--surface)', color: 'var(--ink-2)',
            }}>not them</button>
          </div>
        )}

        <div className="card mt-12" style={{ padding: 12, display: 'flex', gap: 12, alignItems: 'center' }}>
          <div className="photo-thumb photo-thumb-sm" style={{ flexShrink: 0 }}>BADGE</div>
          <div style={{ flex: 1 }}>
            <div className="row" style={{ gap: 6 }}>
              <span className="pill pill-ai">
                <Ic.Sparkle size={12} />
                AI reading
              </span>
            </div>
            <div className="t-meta mt-8" style={{ color: 'var(--ink-2)' }}>
              4 of 6 fields captured
            </div>
            <div style={{ height: 4, background: 'var(--paper-3)', borderRadius: 999, marginTop: 6, overflow: 'hidden' }}>
              <div style={{ width: '66%', height: '100%', background: 'var(--ink)', borderRadius: 999 }} />
            </div>
          </div>
        </div>

        <div className="card mt-12">
          <div className="t-eyebrow" style={{ marginBottom: 10 }}>Captured</div>
          <div className="check-list">
            {checks.map((c) => (
              <div key={c.label} className={`check-row ${c.done ? 'is-done' : ''}`}>
                <div className="ck">
                  {c.done && <Ic.Check size={12} strokeWidth={2.5} />}
                </div>
                <span className="label">{c.label}</span>
                {c.value && <span className="value">{c.value}</span>}
              </div>
            ))}
          </div>
        </div>

        <div className="tx-bubble mt-12">
          <div className="t-eyebrow" style={{ color: 'var(--live)' }}>Transcript</div>
          {transcript.map((t, i) => (
            <div key={i} className={`tx-line ${t.role === 'ai' ? 'is-ai' : 'is-rep'}`}>
              <span className="who">{t.who}</span>
              <span className="text">{t.text}</span>
            </div>
          ))}
        </div>

        <div className="spacer" style={{ minHeight: 8 }} />
      </div>
      <div className="scr-foot">
        <div className="row" style={{ gap: 8, marginBottom: 10 }}>
          <button className="icon-btn"><Ic.Camera size={18} /></button>
          <button className="icon-btn"><Ic.Image size={18} /></button>
          <input
            className="input"
            style={{ flex: 1, height: 44, fontSize: 14 }}
            placeholder="Type a note to the AI…"
          />
        </div>
        <button className="cap-btn is-recording" onClick={onStop}>
          <span className="cap-ring" />
          Stop & save
        </button>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 05 · Capture — Uploading
// ──────────────────────────────────────────────────────────────
function CaptureUploadingScreen({ showName = 'Tech Summit 2026' }) {
  return (
    <div className="scr">
      <TopBar left={<div className="t-eyebrow" style={{ whiteSpace: 'nowrap' }}>{showName}</div>} right={null} />
      <div className="scr-body" style={{ justifyContent: 'center', alignItems: 'center' }}>
        <div className="success">
          <div className="ring" style={{ background: 'transparent', borderColor: 'var(--ink)' }}>
            <Waveform bars={4} color="var(--ink)" />
          </div>
          <div>
            <h1 className="t-h2">Uploading…</h1>
            <div className="t-meta mt-8">Audio, photo, and transcript on their way.</div>
          </div>
        </div>
      </div>
      <div className="scr-foot" />
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 06 · Capture — Queued (offline)
// ──────────────────────────────────────────────────────────────
function CaptureQueuedScreen({ onNew, onLeads, queueCount = 3 }) {
  return (
    <div className="scr">
      <TopBar
        left={<BrandMark subtle />}
        right={<QueuePill count={queueCount} />}
      />
      <div className="scr-body" style={{ paddingTop: 16 }}>
        <div className="success">
          <div className="ring" style={{ background: 'var(--warn-wash)', borderColor: 'var(--warn)', color: 'var(--warn)' }}>
            <Ic.Cloudoff size={36} strokeWidth={1.8} />
          </div>
          <div>
            <h1 className="t-h2">Saved offline</h1>
            <div className="t-meta mt-8" style={{ maxWidth: 280 }}>
              No signal — we tucked this one away. <br/>
              Will upload the moment you reconnect.
            </div>
          </div>

          <div className="card-flat" style={{ alignSelf: 'stretch', textAlign: 'left' }}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <div className="t-tiny" style={{ fontWeight: 600, color: 'var(--ink-2)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                Queue
              </div>
              <div className="t-tiny" style={{ color: 'var(--ink-4)' }}>tap to retry</div>
            </div>
            <div className="col gap-8 mt-8">
              {[
                { code: 'ABC-742', who: 'David Chen', age: 'just now' },
                { code: 'KQ7-301', who: 'New capture', age: '2m ago' },
                { code: 'PMR-918', who: 'Sara Patel',  age: '14m ago' },
              ].map((q, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
                  <span style={{ width: 6, height: 6, borderRadius: 999, background: 'var(--warn)', flexShrink: 0 }} />
                  <span className="op-code" style={{ fontSize: 12, color: 'var(--ink-2)', flexShrink: 0 }}>{q.code}</span>
                  <span style={{ color: 'var(--ink-3)', flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {q.who}
                  </span>
                  <span className="t-tiny" style={{ flexShrink: 0, whiteSpace: 'nowrap' }}>{q.age}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="scr-foot">
        <div className="row gap-8">
          <button className="btn btn-ghost btn-block" onClick={onLeads}>View leads</button>
          <button className="btn btn-primary btn-block" onClick={onNew}>New capture</button>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 07 · Capture — Done (success, online)
// ──────────────────────────────────────────────────────────────
function CaptureDoneScreen({ onNew, onLeads, code = 'ABC-742', merged = true }) {
  return (
    <div className="scr">
      <TopBar left={<BrandMark subtle />} right={<QueuePill count={0} />} />
      <div className="scr-body" style={{ paddingTop: 16 }}>
        <div className="success">
          <div className="ring">
            <Ic.Check size={42} strokeWidth={2} />
          </div>
          <div>
            <div className="t-eyebrow" style={{ color: 'var(--accent)' }}>
              {merged ? 'Merged into existing lead' : 'New lead captured'}
            </div>
            <div className="op-code-lg mt-12" style={{ color: 'var(--ink)' }}>{code}</div>
            <div className="t-meta mt-12" style={{ color: 'var(--ink-3)' }}>David Chen · Acme Robotics</div>
          </div>

          <div className="card-flat" style={{ alignSelf: 'stretch', textAlign: 'left' }}>
            <div className="row" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div className="t-tiny" style={{ fontWeight: 600, color: 'var(--ink-2)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                This capture
              </div>
              <div className="t-tiny">28s audio · badge photo</div>
            </div>
            <div className="col gap-4 mt-12">
              {[
                ['Name', 'David Chen'],
                ['Title', 'VP Engineering'],
                ['Email', 'd.chen@acme.io'],
                ['Interest', 'High · pilot Q3'],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'grid', gridTemplateColumns: '70px 1fr', gap: 10, fontSize: 13, alignItems: 'baseline' }}>
                  <span style={{ color: 'var(--ink-3)' }}>{k}</span>
                  <span style={{ color: 'var(--ink)', fontWeight: 500, textAlign: 'left', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="scr-foot">
        <div className="row gap-8">
          <button className="btn btn-ghost btn-block" onClick={onLeads}>View leads</button>
          <button className="btn btn-primary btn-block" onClick={onNew}>New capture</button>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 08 · Leads list
// ──────────────────────────────────────────────────────────────
function LeadsScreen({ onBack, queue = 0, syncing = 0, onQueueTap, showName = 'Tech Summit 2026' }) {
  const filters = ['All · 38', 'Today', 'Missing fields', 'High intent', 'Mine'];
  const leads = [
    {
      name: 'David Chen', co: 'Acme Robotics', title: 'VP Engineering',
      code: 'ABC-742', by: 'RM', conf: 'high', missing: [],
      time: '2m', captures: 2, intent: 'High',
    },
    {
      name: 'Sara Patel', co: 'Northwind Cloud', title: 'Director of Eng',
      code: 'KQ7-301', by: 'SC', conf: 'mid', missing: ['phone'],
      time: '14m', captures: 1, intent: 'Med',
    },
    {
      name: 'Marcus Field', co: 'Volta Mobility', title: 'CTO',
      code: 'PMR-918', by: 'RM', conf: 'high', missing: ['email','best time'],
      time: '38m', captures: 1, intent: 'High',
    },
    {
      name: '(no name yet)', co: '—', title: '',
      code: 'JZN-204', by: 'SC', conf: 'low', missing: ['name','company','email'],
      time: '1h', captures: 1, intent: '',
    },
    {
      name: 'Lin Wei', co: 'Helio Energy', title: 'Head of Robotics',
      code: 'XB4-559', by: 'RM', conf: 'high', missing: [],
      time: '1h', captures: 1, intent: 'Low',
    },
  ];
  return (
    <div className="scr">
      <TopBar
        left={
          <button className="icon-btn" onClick={onBack} style={{ width: 36, height: 36, borderRadius: 10 }}>
            <Ic.LeftArrow size={18} />
          </button>
        }
        right={
          <div className="row gap-8">
            <QueuePill count={queue} syncing={syncing} onClick={onQueueTap} />
            <button className="icon-btn" style={{ width: 36, height: 36, borderRadius: 10 }}>
              <Ic.Download size={18} />
            </button>
          </div>
        }
      />
      <div className="scr-body">
        <div>
          <div className="t-eyebrow">{showName}</div>
          <div className="row" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
            <h1 className="t-title" style={{ marginTop: 6 }}>Leads</h1>
            <div className="t-meta" style={{ color: 'var(--ink-3)' }}>38 · 5 missing fields</div>
          </div>
        </div>

        <div className="filter-row mt-16">
          {filters.map((f, i) => (
            <div key={f} className={`filter-chip ${i === 0 ? 'is-active' : ''}`}>{f}</div>
          ))}
        </div>

        <div className="col gap-12 mt-16">
          {leads.map((l) => (
            <div key={l.code} className="lead-card">
              <div className="hd">
                <div style={{ minWidth: 0 }}>
                  <div className="name">{l.name}</div>
                  <div className="co">{l.co}{l.title && <> · {l.title}</>}</div>
                </div>
                <span className="op-code" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{l.code}</span>
              </div>
              {(l.missing.length > 0 || l.intent) && (
                <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
                  {l.intent && (
                    <span className="chip" style={{
                      background: l.intent === 'High' ? 'var(--accent-wash)' : 'var(--paper-2)',
                      color: l.intent === 'High' ? 'var(--accent)' : 'var(--ink-3)',
                    }}>
                      {l.intent} intent
                    </span>
                  )}
                  {l.missing.map((m) => (
                    <span key={m} className="chip chip-missing">missing · {m}</span>
                  ))}
                </div>
              )}
              <div className="footer">
                <span style={{
                  width: 6, height: 6, borderRadius: 999,
                  background: l.conf === 'high' ? 'var(--ok)' : l.conf === 'mid' ? 'var(--warn)' : 'var(--ink-5)',
                }} />
                <span className="t-tiny">{l.captures} capture{l.captures === 1 ? '' : 's'} · {l.time} ago</span>
                <span className="by">{l.by}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="scr-foot" style={{ paddingBottom: 36 }}>
        <button className="btn btn-accent btn-block">
          <Ic.Plus size={18} />
          New capture
        </button>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 09 · Show switcher sheet (bottom sheet over capture)
// ──────────────────────────────────────────────────────────────
function ShowSwitcherSheet({ currentCode = 'TS26', onPick, onClose }) {
  const shows = [
    { code: 'TS26', name: 'Tech Summit 2026', when: 'Today · Hall B', leads: 38, badge: 'TS', live: true },
    { code: 'RNX',  name: 'Robotics Expo NYC', when: 'Apr 14–16',    leads: 124, badge: 'RX', live: false, swatch: 'alt-1' },
    { code: 'DEV',  name: 'DevWorld London',   when: 'May 02–04',    leads: 0,   badge: 'DW', live: false, swatch: 'alt-2' },
  ];
  return (
    <div className="sheet-host" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="handle" />
        <div className="sheet-hd">
          <h2>Switch show</h2>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, border: 0, background: 'var(--paper-2)',
              borderRadius: 10, color: 'var(--ink-3)', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <Ic.X size={16} />
          </button>
        </div>
        <div className="sheet-body">
          {shows.map((s) => (
            <div
              key={s.code}
              className={`pick-row ${s.code === currentCode ? 'is-current' : ''}`}
              onClick={() => onPick?.(s)}
            >
              <div className={`swatch ${s.swatch || ''}`} style={{
                width: 40, height: 40, borderRadius: 10,
                background: s.swatch === 'alt-1' ? '#1B1A17' :
                            s.swatch === 'alt-2' ? 'var(--paper-3)' : 'var(--accent)',
                color: s.swatch === 'alt-2' ? 'var(--ink)' :
                       s.swatch === 'alt-1' ? '#FAFAF6' : 'var(--accent-ink)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--mono)', fontWeight: 600, fontSize: 12,
                flexShrink: 0,
              }}>{s.badge}</div>
              <div className="mid">
                <div className="row" style={{ gap: 8 }}>
                  <div className="nm">{s.name}</div>
                  {s.live && <LivePill label="today" />}
                </div>
                <div className="sub">
                  <span className="op-code">{s.code}</span>
                  <span style={{ margin: '0 6px', color: 'var(--ink-5)' }}>·</span>
                  {s.when}
                  <span style={{ margin: '0 6px', color: 'var(--ink-5)' }}>·</span>
                  {s.leads} leads
                </div>
              </div>
              {s.code === currentCode ? (
                <div className="right">
                  <span className="pill pill-ok" style={{ height: 22, fontSize: 11 }}>
                    <Ic.Check size={11} />
                    current
                  </span>
                </div>
              ) : (
                <Ic.Chev size={16} color="var(--ink-4)" />
              )}
            </div>
          ))}

          <button className="card-flat mt-12" style={{
            border: 0, background: 'var(--paper-2)', color: 'var(--ink-2)',
            display: 'flex', gap: 10, alignItems: 'center',
            cursor: 'pointer', font: 'inherit', textAlign: 'left',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: 'var(--surface)', color: 'var(--ink-2)',
              border: '1px solid var(--rule-2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Ic.QR size={18} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Join a show</div>
              <div className="t-tiny mt-4">Scan a code from the booth lead or paste an invite link.</div>
            </div>
            <Ic.Chev size={16} color="var(--ink-4)" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 10 · Lead picker sheet — pick an existing lead to add capture to
// ──────────────────────────────────────────────────────────────
function LeadPickerSheet({ onPick, onClose }) {
  const recent = [
    { name: 'David Chen',   co: 'Acme Robotics',   code: 'ABC-742', age: '2m',  badge: 'just now' },
    { name: 'Sara Patel',   co: 'Northwind Cloud', code: 'KQ7-301', age: '14m', missing: 'phone' },
    { name: 'Marcus Field', co: 'Volta Mobility',  code: 'PMR-918', age: '38m', missing: '2 fields' },
    { name: 'Lin Wei',      co: 'Helio Energy',    code: 'XB4-559', age: '1h' },
    { name: 'Priya Anand',  co: 'Boldline AI',     code: 'TR9-005', age: '2h' },
    { name: 'Jordan Reyes', co: 'Stellar Optics',  code: 'YH3-227', age: '3h' },
  ];
  return (
    <div className="sheet-host" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="handle" />
        <div className="sheet-hd">
          <div>
            <h2>Add to existing</h2>
            <div className="t-tiny mt-4">This capture will be merged into the lead you pick.</div>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, border: 0, background: 'var(--paper-2)',
              borderRadius: 10, color: 'var(--ink-3)', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <Ic.X size={16} />
          </button>
        </div>

        <div className="search-input" style={{ marginBottom: 14 }}>
          <Ic.Search size={16} color="var(--ink-4)" />
          <input placeholder="Search name, company, or code…" />
        </div>

        <div className="t-eyebrow" style={{ marginBottom: 8 }}>Recent · this booth</div>
        <div className="sheet-body">
          {recent.map((l) => (
            <div key={l.code} className="pick-row" onClick={() => onPick?.(l)}>
              <div style={{
                width: 36, height: 36, borderRadius: 10,
                background: 'var(--paper-2)', color: 'var(--ink-2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0, fontWeight: 600, fontSize: 13,
              }}>
                {l.name.split(' ').map((p) => p[0]).slice(0, 2).join('')}
              </div>
              <div className="mid">
                <div className="row" style={{ gap: 6 }}>
                  <span className="nm">{l.name}</span>
                </div>
                <div className="sub">
                  {l.co}
                  <span style={{ margin: '0 6px', color: 'var(--ink-5)' }}>·</span>
                  <span className="op-code" style={{ fontSize: 11 }}>{l.code}</span>
                  {l.missing && (
                    <>
                      <span style={{ margin: '0 6px', color: 'var(--ink-5)' }}>·</span>
                      <span style={{ color: 'var(--warn)' }}>missing {l.missing}</span>
                    </>
                  )}
                </div>
              </div>
              <div className="right">{l.age}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 11 · Admin — Team / Invites
// ──────────────────────────────────────────────────────────────
function TeamScreen({ onBack, showName = 'Tech Summit 2026' }) {
  const team = [
    { email: 'sam@yourcompany.com',      name: 'Sam Cohen',    role: 'lead',    status: 'active' },
    { email: 'riley@yourcompany.com',    name: 'Riley Moss',   role: 'rep',     status: 'active' },
    { email: 'jordan@yourcompany.com',   name: 'Jordan Reyes', role: 'rep',     status: 'active' },
    { email: 'priya@yourcompany.com',    name: 'Priya Anand',  role: 'rep',     status: 'invited' },
  ];
  // simple stable QR-ish dot pattern
  const qrCells = Array.from({ length: 100 }).map((_, i) => {
    const x = i % 10, y = Math.floor(i / 10);
    const corners =
      (x < 3 && y < 3) || (x > 6 && y < 3) || (x < 3 && y > 6);
    const stable = (x * 7 + y * 13 + (x ^ y) * 5) % 7;
    return corners
      ? !((x === 1 || x === 8) && (y === 1)) && !((x === 1) && (y === 8))
      : stable > 3;
  });
  return (
    <div className="scr">
      <TopBar
        left={
          <button className="icon-btn" onClick={onBack} style={{ width: 36, height: 36, borderRadius: 10 }}>
            <Ic.LeftArrow size={18} />
          </button>
        }
        right={null}
      />
      <div className="scr-body">
        <div>
          <div className="t-eyebrow" style={{ whiteSpace: 'nowrap' }}>{showName}  ·  admin</div>
          <h1 className="t-title" style={{ marginTop: 6 }}>Team & invites</h1>
          <div className="t-meta mt-8">
            Reps need a sign-in (magic link) <em>and</em> a membership in this show to capture leads.
          </div>
        </div>

        <Section label="Invite link">
          <div className="invite-link">
            <div className="row" style={{ gap: 12 }}>
              <div className="qr-block">
                {qrCells.map((on, i) => (
                  <i key={i} style={{ visibility: on ? 'visible' : 'hidden' }} />
                ))}
              </div>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8, minWidth: 0 }}>
                <div className="t-tiny" style={{ color: 'var(--ink-3)', fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
                  Scan or share
                </div>
                <div className="link">capture.red5.co/join/TS26-9k2pq</div>
                <div className="row gap-8">
                  <span className="chip" style={{ background: 'var(--paper-2)' }}>
                    role · rep
                  </span>
                  <span className="chip" style={{ background: 'var(--paper-2)' }}>
                    expires in 7d
                  </span>
                </div>
              </div>
            </div>
            <div className="row gap-8">
              <button className="btn btn-sub btn-sm" style={{ flex: 1 }}>
                <Ic.Hash size={14} />Copy link
              </button>
              <button className="btn btn-sub btn-sm" style={{ flex: 1 }}>
                <Ic.Mail size={14} />Email link
              </button>
              <button className="btn btn-sub btn-sm" style={{ flex: 1 }}>
                <Ic.Plus size={14} />New link
              </button>
            </div>
          </div>
        </Section>

        <Section label="Members · 4">
          <div className="col" style={{ gap: 8 }}>
            {team.map((m) => (
              <div key={m.email} className="card" style={{
                padding: '10px 14px',
                display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '50%',
                  background: m.status === 'invited' ? 'var(--warn-wash)' : 'var(--paper-2)',
                  color: m.status === 'invited' ? 'var(--warn)' : 'var(--ink-2)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontWeight: 600, fontSize: 13, flexShrink: 0,
                }}>
                  {m.name.split(' ').map((p) => p[0]).slice(0, 2).join('')}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="row" style={{ gap: 6 }}>
                    <span style={{ fontWeight: 600, fontSize: 14 }}>{m.name}</span>
                    <span className={`role-tag ${m.role}`}>{m.role}</span>
                    {m.status === 'invited' && (
                      <span className="role-tag invited">invited</span>
                    )}
                  </div>
                  <div className="t-tiny mt-4" style={{
                    whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                  }}>{m.email}</div>
                </div>
                <button className="icon-btn" style={{ width: 32, height: 32, borderRadius: 8 }}>
                  <Ic.More size={16} />
                </button>
              </div>
            ))}
          </div>
        </Section>

        <div className="spacer" />
      </div>
      <div className="scr-foot">
        <button className="btn btn-primary btn-block">
          <Ic.Plus size={18} />
          Invite by email
        </button>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// 12 · Queue / outbox sheet — non-blocking inspection of in-flight work
// ──────────────────────────────────────────────────────────────
function QueueSheet({ onClose, items = null }) {
  const defaults = [
    { code: 'ABC-742', who: 'David Chen',  age: 'just now', status: 'uploading', progress: 0.62 },
    { code: 'KQ7-301', who: 'Sara Patel',  age: '2m ago',   status: 'queued' },
    { code: 'PMR-918', who: 'Marcus Field', age: '14m ago', status: 'queued' },
  ];
  const list = items || defaults;
  return (
    <div className="sheet-host" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="handle" />
        <div className="sheet-hd">
          <div>
            <h2>Outbox</h2>
            <div className="t-tiny mt-4">
              Captures upload in the background. You can keep working.
            </div>
          </div>
          <button
            onClick={onClose}
            style={{
              width: 32, height: 32, border: 0, background: 'var(--paper-2)',
              borderRadius: 10, color: 'var(--ink-3)', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <Ic.X size={16} />
          </button>
        </div>
        <div className="sheet-body" style={{ gap: 10 }}>
          {list.map((q, i) => (
            <div key={i} className={`q-row is-${q.status}`}>
              <span className="dot" />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="row" style={{ gap: 8 }}>
                  <span className="op-code" style={{ fontSize: 12 }}>{q.code}</span>
                  <span style={{
                    fontSize: 13, color: 'var(--ink-2)',
                    overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                  }}>{q.who}</span>
                  <span className="t-tiny" style={{ marginLeft: 'auto', flexShrink: 0 }}>{q.age}</span>
                </div>
                {q.status === 'uploading' && (
                  <div className="stk-bar">
                    <i style={{ width: `${Math.round((q.progress || 0.4) * 100)}%` }} />
                  </div>
                )}
                {q.status === 'queued' && (
                  <div className="t-tiny mt-4" style={{ color: 'var(--warn)' }}>
                    waiting · will upload when online
                  </div>
                )}
                {q.status === 'failed' && (
                  <div className="t-tiny mt-4" style={{ color: 'var(--accent)' }}>
                    upload failed · tap retry
                  </div>
                )}
              </div>
              {q.status === 'failed' && (
                <button className="btn btn-sm btn-sub" style={{ flexShrink: 0 }}>retry</button>
              )}
            </div>
          ))}
          {list.length === 0 && (
            <div className="card-flat" style={{ textAlign: 'center', padding: 24, color: 'var(--ink-3)' }}>
              Nothing in flight. All captures synced.
            </div>
          )}
        </div>
        <div className="t-tiny mt-12" style={{ textAlign: 'center', color: 'var(--ink-4)' }}>
          Auto-retry on reconnect · last sync 14s ago
        </div>
      </div>
    </div>
  );
}

// Export to global
Object.assign(window, {
  SignInScreen, HomeScreen, CaptureReadyScreen, CaptureLiveScreen,
  CaptureUploadingScreen, CaptureQueuedScreen, CaptureDoneScreen, LeadsScreen,
  ShowSwitcherSheet, LeadPickerSheet, TeamScreen, QueueSheet,
  Toggle,
});
