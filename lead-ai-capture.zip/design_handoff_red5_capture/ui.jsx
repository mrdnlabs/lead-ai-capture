// ui.jsx — base components & icons for red5 / capture
// (No imports — assumes React global from index.html.)

const { useState, useEffect, useRef, useMemo } = React;

// ──────────────────────────────────────────────────────────────
// Icons — line set, 24px stroke 1.6
// ──────────────────────────────────────────────────────────────
const Ic = {};
const _icon = (paths, size = 20) => ({ size: s = size, color = 'currentColor', strokeWidth: sw = 1.6, ...rest } = {}) => (
  <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={color}
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {paths}
  </svg>
);
Ic.Mic = _icon(<>
  <rect x="9" y="3" width="6" height="12" rx="3" />
  <path d="M5 11a7 7 0 0 0 14 0" />
  <path d="M12 18v3" />
</>);
Ic.Stop = _icon(<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none" />);
Ic.Camera = _icon(<>
  <path d="M3 8.5A1.5 1.5 0 0 1 4.5 7H8l1.5-2h5L16 7h3.5A1.5 1.5 0 0 1 21 8.5v9A1.5 1.5 0 0 1 19.5 19h-15A1.5 1.5 0 0 1 3 17.5v-9Z" />
  <circle cx="12" cy="13" r="3.5" />
</>);
Ic.Image = _icon(<>
  <rect x="3" y="4" width="18" height="16" rx="2" />
  <circle cx="9" cy="10" r="1.5" />
  <path d="M3 17l5-5 4 4 3-3 6 6" />
</>);
Ic.Send = _icon(<><path d="M3 11l18-8-8 18-2-8z" /></>);
Ic.Check = _icon(<polyline points="5 12 10 17 19 7" />);
Ic.X = _icon(<><path d="M6 6l12 12M18 6L6 18" /></>);
Ic.Chev = _icon(<polyline points="9 6 15 12 9 18" />);
Ic.Plus = _icon(<><path d="M12 5v14M5 12h14" /></>);
Ic.Search = _icon(<>
  <circle cx="11" cy="11" r="7" />
  <path d="M20 20l-3.5-3.5" />
</>);
Ic.Sparkle = _icon(<>
  <path d="M12 3l1.7 4.3L18 9l-4.3 1.7L12 15l-1.7-4.3L6 9l4.3-1.7L12 3z" />
  <path d="M19 16l.7 1.6L21 18l-1.3.4L19 20l-.7-1.6L17 18l1.3-.4z" />
</>);
Ic.Wifi = _icon(<>
  <path d="M5 12a10 10 0 0 1 14 0" />
  <path d="M8.5 15.5a5 5 0 0 1 7 0" />
  <circle cx="12" cy="19" r="1.2" fill="currentColor" stroke="none" />
</>);
Ic.Cloud = _icon(<>
  <path d="M7 18a4 4 0 1 1 1.2-7.8A5 5 0 0 1 18 11a3.5 3.5 0 0 1 0 7H7z" />
</>);
Ic.Cloudoff = _icon(<>
  <path d="M3 3l18 18" />
  <path d="M9 5.5A5 5 0 0 1 18 11a3.5 3.5 0 0 1 3 3.5 3.5 3.5 0 0 1-.6 2" />
  <path d="M7 18a4 4 0 0 1-1.7-7.6" />
</>);
Ic.Download = _icon(<>
  <path d="M12 4v12" />
  <path d="M7 11l5 5 5-5" />
  <path d="M5 20h14" />
</>);
Ic.QR = _icon(<>
  <rect x="3" y="3" width="7" height="7" rx="1" />
  <rect x="14" y="3" width="7" height="7" rx="1" />
  <rect x="3" y="14" width="7" height="7" rx="1" />
  <path d="M14 14h3v3M21 14v3M14 21h3M21 18v3" />
</>);
Ic.More = _icon(<>
  <circle cx="6" cy="12" r="1.4" fill="currentColor" stroke="none"/>
  <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/>
  <circle cx="18" cy="12" r="1.4" fill="currentColor" stroke="none"/>
</>);
Ic.Arrow = _icon(<><path d="M5 12h14" /><path d="M13 6l6 6-6 6" /></>);
Ic.User = _icon(<>
  <circle cx="12" cy="8" r="4" />
  <path d="M4 21a8 8 0 0 1 16 0" />
</>);
Ic.Mail = _icon(<>
  <rect x="3" y="5" width="18" height="14" rx="2" />
  <path d="M3 7l9 7 9-7" />
</>);
Ic.Sun = _icon(<>
  <circle cx="12" cy="12" r="4" />
  <path d="M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5" />
</>);
Ic.Moon = _icon(<path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z" />);
Ic.Hash = _icon(<><path d="M5 9h14M5 15h14M9 4l-2 16M17 4l-2 16" /></>);
Ic.LeftArrow = _icon(<><path d="M19 12H5" /><path d="M11 6l-6 6 6 6" /></>);

// ──────────────────────────────────────────────────────────────
// Brand mark
// ──────────────────────────────────────────────────────────────
function BrandMark({ subtle = false }) {
  return (
    <div className="brand">
      <span className="brand-dot" />
      <span style={{ color: subtle ? 'var(--ink-3)' : 'var(--ink)' }}>capture</span>
      <span style={{ color: 'var(--ink-4)', fontWeight: 500, fontSize: 11, letterSpacing: '0.04em', textTransform: 'uppercase', marginLeft: 4 }}>
        by red5
      </span>
    </div>
  );
}

// Just the corner mark — for capture screens
// Queue / sync pill — header micro-indicator. Never blocks UI.
function QueuePill({ count = 0, syncing = 0, onClick }) {
  if (syncing > 0) {
    return (
      <button className="pill pill-ai" style={{ border: 0, cursor: 'pointer', height: 28 }} onClick={onClick}>
        <span style={{
          width: 10, height: 10, borderRadius: '50%',
          border: '1.5px solid currentColor', borderTopColor: 'transparent',
          animation: 'spin 0.9s linear infinite', display: 'inline-block',
        }} />
        syncing {syncing}
      </button>
    );
  }
  if (count > 0) {
    return (
      <button className="pill pill-warn" style={{ border: 0, cursor: 'pointer', height: 28 }} onClick={onClick}>
        <span style={{ display: 'inline-flex' }}>
          <Ic.Cloudoff size={14} />
        </span>
        {count} queued
      </button>
    );
  }
  return (
    <div className="pill" style={{ background: 'transparent', height: 28 }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--ok)' }} />
      synced
    </div>
  );
}

// Toast — short ambient notification. Use to confirm capture, queue, sync.
function Toast({ kind = 'ok', icon, title, meta, action, onAction }) {
  const bg = kind === 'offline' ? 'var(--warn-wash)'
          : kind === 'accent'  ? 'var(--accent-wash)'
          : 'var(--ink)';
  const fg = kind === 'offline' ? 'var(--warn)'
          : kind === 'accent'  ? 'var(--accent)'
          : 'var(--paper)';
  return (
    <div className="toast" style={{ background: bg, color: fg }}>
      <span style={{ display: 'inline-flex', flexShrink: 0 }}>{icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: 14, lineHeight: 1.2 }}>{title}</div>
        {meta && <div style={{ fontSize: 12, opacity: 0.78, marginTop: 2 }}>{meta}</div>}
      </div>
      {action && (
        <button
          onClick={onAction}
          style={{
            flexShrink: 0, height: 28, padding: '0 10px', borderRadius: 8, fontSize: 12,
            fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer',
            border: '1px solid currentColor', background: 'transparent', color: 'inherit',
          }}
        >
          {action}
        </button>
      )}
    </div>
  );
}

// Live status pill
function LivePill({ label = 'Live' }) {
  return (
    <span className="pill pill-live">
      <span className="dot" />
      {label}
    </span>
  );
}

// ──────────────────────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────────────────────
function Waveform({ bars = 5, height = 32, color }) {
  return (
    <div className="wave" style={{ color: color || 'currentColor', height }}>
      {Array.from({ length: bars }).map((_, i) => (
        <i key={i} style={{ animationDelay: `${i * 0.12}s` }} />
      ))}
    </div>
  );
}

function Section({ children, label, right }) {
  return (
    <div className="col" style={{ gap: 10, marginTop: 16 }}>
      {(label || right) && (
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <div className="t-eyebrow">{label}</div>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

// Topbar of the app — used inside iPhone frame
function TopBar({ left, right, dense = false }) {
  return (
    <div className="scr-top" style={{ paddingTop: dense ? 56 : 64 }}>
      <div>{left}</div>
      <div className="row gap-8">{right}</div>
    </div>
  );
}

// Export to global scope so screens.jsx + app.jsx can use them
Object.assign(window, {
  Ic, BrandMark, QueuePill, LivePill, Waveform, Section, TopBar, Toast,
  useState, useEffect, useRef, useMemo,
});
