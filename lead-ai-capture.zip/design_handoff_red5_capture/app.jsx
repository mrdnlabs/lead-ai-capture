// app.jsx — main app: design canvas + interactive prototype + tweaks
// Uses globals from ui.jsx and screens.jsx.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#D63E2C",
  "dark": false
}/*EDITMODE-END*/;

// Accent color → CSS variable override
function applyAccent(hex) {
  // Map hex to oklch-ish accent vars by setting --accent directly.
  // Calc the wash/line by hand-picking lightness deltas.
  const root = document.documentElement;
  root.style.setProperty('--accent', hex);
}

// Wraps an iOS frame around any of our screens
function PhoneFrame({ children, dark, label }) {
  return (
    <div style={{ position: 'relative' }} data-screen-label={label}>
      <IOSDevice width={390} height={780} dark={dark}>
        <div style={{ height: '100%', background: 'var(--paper)' }}>
          {children}
        </div>
      </IOSDevice>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Interactive prototype — drives through the capture flow
// ──────────────────────────────────────────────────────────────
function InteractivePhone({ dark }) {
  const [route, setRoute] = useState('ready');
  const [sheet, setSheet] = useState(null); // 'switch' | 'pick' | 'queue' | null
  const [elapsed, setElapsed] = useState(0);
  const [queue, setQueue] = useState(0);      // items waiting (offline)
  const [syncing, setSyncing] = useState(0);  // items currently uploading
  const [offline, setOffline] = useState(false);
  const [show, setShow] = useState({ badge: 'TS', name: 'Tech Summit 2026', code: 'TS26' });
  const [targetLead, setTargetLead] = useState(null);
  const [toast, setToast] = useState(null);   // {kind, icon, title, meta, action}
  const tickerRef = useRef(null);
  const toastTimerRef = useRef(null);

  useEffect(() => {
    if (route === 'live') {
      tickerRef.current = setInterval(() => setElapsed((e) => e + 1), 1000);
    } else {
      clearInterval(tickerRef.current);
      if (route !== 'live') setElapsed(0);
    }
    return () => clearInterval(tickerRef.current);
  }, [route]);

  function showToast(t, ms = 3200) {
    setToast(t);
    clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToast(null), ms);
  }

  function record() {
    setElapsed(0);
    setRoute('live');
  }

  // Stop & save — never block the UI. Upload happens in background.
  function stop() {
    const code = targetLead?.code || ('K' + Math.floor(Math.random() * 900 + 100) + '-' + Math.floor(Math.random() * 900 + 100));
    const who = targetLead?.name || 'David Chen';
    const merged = !!targetLead;
    setRoute('ready');
    setTargetLead(null);

    if (offline) {
      setQueue((q) => q + 1);
      showToast({
        kind: 'offline',
        icon: <Ic.Cloudoff size={18} />,
        title: 'Saved offline',
        meta: `${code} · will upload when you reconnect`,
        action: 'View queue',
        onAction: () => { setToast(null); setSheet('queue'); },
      });
    } else {
      setSyncing((s) => s + 1);
      showToast({
        kind: merged ? 'accent' : 'ok',
        icon: merged ? <Ic.Sparkle size={18} /> : <Ic.Check size={18} />,
        title: merged ? `Added to ${who}` : 'Capture saved',
        meta: `${code} · uploading in background`,
      });
      setTimeout(() => setSyncing((s) => Math.max(0, s - 1)), 1800);
    }
  }

  // Reconnect — flush the offline queue
  function flushQueue() {
    if (queue === 0) return;
    const n = queue;
    setSyncing((s) => s + n);
    setQueue(0);
    showToast({
      kind: 'accent',
      icon: <Ic.Cloud size={18} />,
      title: `Back online · syncing ${n}`,
      meta: 'Captures uploading in background',
    });
    setTimeout(() => setSyncing((s) => Math.max(0, s - n)), 2400);
  }

  // Auto-flush when user toggles offline -> online
  const prevOffline = useRef(offline);
  useEffect(() => {
    if (prevOffline.current && !offline && queue > 0) flushQueue();
    prevOffline.current = offline;
  }, [offline]);

  let screen;
  switch (route) {
    case 'signin':
      screen = <SignInScreen email="riley@yourcompany.com" sent={false} onSubmit={() => setRoute('ready')} />;
      break;
    case 'ready':
      screen = (
        <CaptureReadyScreen
          queue={queue}
          syncing={syncing}
          onQueueTap={() => setSheet('queue')}
          show={show}
          targetLead={targetLead}
          onStart={record}
          onSwitchShow={() => setSheet('switch')}
          onPickLead={() => setSheet('pick')}
          onClearTarget={() => setTargetLead(null)}
        />
      );
      break;
    case 'live':
      screen = <CaptureLiveScreen
        elapsed={elapsed}
        onStop={stop}
        showName={show.name}
        match={!targetLead}
        code={targetLead?.code || 'ABC-742'} />;
      break;
    case 'leads':
      screen = <LeadsScreen
        queue={queue} syncing={syncing}
        onQueueTap={() => setSheet('queue')}
        onBack={() => setRoute('ready')} showName={show.name} />;
      break;
    case 'team':
      screen = <TeamScreen onBack={() => setRoute('ready')} showName={show.name} />;
      break;
    default:
      screen = <CaptureReadyScreen show={show} onStart={record} onSwitchShow={() => setSheet('switch')} onPickLead={() => setSheet('pick')} />;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, alignItems: 'center' }}>
      <PhoneFrame dark={dark} label="Interactive prototype">
        <div style={{ position: 'relative', height: '100%' }}>
          {screen}
          {/* Ambient toast — never blocks taps below */}
          {toast && (
            <div className="toast-host">
              <Toast {...toast} />
            </div>
          )}
          {sheet === 'switch' && (
            <ShowSwitcherSheet
              currentCode={show.code}
              onClose={() => setSheet(null)}
              onPick={(s) => {
                setShow({ badge: s.badge, name: s.name, code: s.code, swatch: s.swatch });
                setSheet(null);
              }}
            />
          )}
          {sheet === 'pick' && (
            <LeadPickerSheet
              onClose={() => setSheet(null)}
              onPick={(l) => {
                setTargetLead({ name: l.name, code: l.code });
                setSheet(null);
              }}
            />
          )}
          {sheet === 'queue' && (
            <QueueSheet
              onClose={() => setSheet(null)}
              items={buildQueueItems(syncing, queue)}
            />
          )}
        </div>
      </PhoneFrame>

      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: 6,
        justifyContent: 'center',
        padding: '12px 14px',
        background: '#ffffff',
        border: '1px solid rgba(0,0,0,0.08)',
        borderRadius: 16,
        boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
        fontFamily: 'Hanken Grotesk, system-ui',
        fontSize: 12,
        maxWidth: 380,
      }}>
        <div style={{
          fontSize: 10, fontWeight: 600, letterSpacing: '0.08em',
          textTransform: 'uppercase', color: '#888', width: '100%', textAlign: 'center',
        }}>
          Prototype controls
        </div>
        {[
          ['signin', 'Sign in'],
          ['ready', 'Capture'],
          ['live', 'Live'],
          ['leads', 'Leads'],
          ['team', 'Team'],
        ].map(([k, l]) => (
          <button key={k}
            onClick={() => setRoute(k)}
            style={{
              padding: '5px 10px',
              border: 0,
              background: route === k ? '#0E0E0C' : '#F2F1EB',
              color: route === k ? '#FAFAF6' : '#2A2A26',
              borderRadius: 8,
              fontSize: 12,
              fontWeight: 500,
              cursor: 'pointer',
            }}>
            {l}
          </button>
        ))}
        <label style={{
          display: 'flex', alignItems: 'center', gap: 6, padding: '5px 10px',
          background: offline ? '#FFEDD5' : '#F2F1EB', borderRadius: 8, fontSize: 12, cursor: 'pointer',
          color: offline ? '#B45309' : '#2A2A26', fontWeight: 500,
        }}>
          <input type="checkbox" checked={offline} onChange={(e) => setOffline(e.target.checked)} />
          {offline ? 'offline · auto-syncs when back' : 'offline'}
        </label>
      </div>
    </div>
  );
}

// Build a representative queue snapshot for the sheet
function buildQueueItems(syncing, queued) {
  const items = [];
  const ages = ['just now', '2m ago', '14m ago', '38m ago'];
  const names = ['David Chen', 'Sara Patel', 'Marcus Field', 'Lin Wei'];
  const codes = ['ABC-742', 'KQ7-301', 'PMR-918', 'XB4-559'];
  for (let i = 0; i < syncing; i++) {
    items.push({ status: 'uploading', code: codes[i % codes.length], who: names[i % names.length], age: ages[i % ages.length], progress: 0.4 + (i * 0.2) % 0.5 });
  }
  for (let i = 0; i < queued; i++) {
    items.push({ status: 'queued', code: codes[(i + syncing) % codes.length], who: names[(i + syncing) % names.length], age: ages[(i + syncing) % ages.length] });
  }
  if (items.length === 0) {
    items.push({ status: 'uploading', code: 'ABC-742', who: 'David Chen', age: 'just now', progress: 0.62 });
    items.push({ status: 'queued', code: 'KQ7-301', who: 'Sara Patel', age: '2m ago' });
  }
  return items;
}

// ──────────────────────────────────────────────────────────────
// Design system reference card (lightweight, lives in the canvas)
// ──────────────────────────────────────────────────────────────
function DesignSystemCard() {
  return (
    <div style={{
      background: 'var(--paper)',
      padding: 28,
      width: 580,
      height: 780,
      borderRadius: 8,
      fontFamily: 'Hanken Grotesk, system-ui',
      color: 'var(--ink)',
      display: 'flex', flexDirection: 'column', gap: 20,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 16 }}>
        <div>
          <div className="t-eyebrow">Design system</div>
          <div className="t-title-lg" style={{ marginTop: 8 }}>red5 / capture</div>
          <div className="t-meta mt-12" style={{ maxWidth: 360 }}>
            Streamlined, elegant, always ready. Built for one hand, a noisy hall, and
            five-second decisions.
          </div>
        </div>
        <BrandMark />
      </div>

      <div className="divider" />

      <div>
        <div className="t-eyebrow">Type</div>
        <div className="mt-12" style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ fontSize: 40, fontWeight: 600, letterSpacing: '-0.03em', lineHeight: 1 }}>
            Hanken Grotesk
          </div>
          <div className="t-meta">UI · 400 / 500 / 600 / 700</div>
          <div style={{ fontFamily: 'JetBrains Mono', fontSize: 22, letterSpacing: '0.10em', marginTop: 8 }}>
            ABC-742  ·  XB4-559
          </div>
          <div className="t-meta">JetBrains Mono · opportunity codes</div>
        </div>
      </div>

      <div className="divider" />

      <div>
        <div className="t-eyebrow">Palette</div>
        <div className="mt-12" style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
          {[
            ['Ink', 'var(--ink)', '#FAFAF6'],
            ['Ink 3', 'var(--ink-3)', '#FAFAF6'],
            ['Paper', 'var(--paper)', '#0E0E0C'],
            ['Paper 2', 'var(--paper-2)', '#0E0E0C'],
            ['Accent', 'var(--accent)', '#fff'],
            ['Live', 'var(--live)', '#fff'],
          ].map(([n, bg, fg]) => (
            <div key={n} style={{
              height: 64, borderRadius: 10, background: bg,
              display: 'flex', alignItems: 'flex-end', padding: 8,
              color: fg, fontSize: 10, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase',
              border: bg.includes('paper') ? '1px solid var(--rule)' : 'none',
            }}>{n}</div>
          ))}
        </div>
      </div>

      <div className="divider" />

      <div>
        <div className="t-eyebrow">Components</div>
        <div className="mt-12" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="row gap-8">
            <button className="btn btn-primary">Primary</button>
            <button className="btn btn-accent">Accent</button>
            <button className="btn btn-ghost">Ghost</button>
          </div>
          <div className="row gap-8" style={{ flexWrap: 'wrap' }}>
            <span className="pill pill-live"><span className="dot" />Live · 00:18</span>
            <span className="pill pill-ai"><Ic.Sparkle size={12} /> AI reading</span>
            <span className="pill pill-ok"><Ic.Check size={12} />Synced</span>
            <span className="pill pill-warn"><Ic.Cloudoff size={12} />3 queued</span>
          </div>
          <div className="row gap-8" style={{ flexWrap: 'wrap' }}>
            <span className="chip">just now</span>
            <span className="chip chip-missing">missing · phone</span>
            <span className="chip" style={{ background: 'var(--accent-wash)', color: 'var(--accent)' }}>High intent</span>
          </div>
          <div className="card-flat" style={{
            display: 'flex', alignItems: 'center', gap: 10,
          }}>
            <span className="op-code" style={{ fontSize: 18, color: 'var(--accent)' }}>ABC-742</span>
            <span className="t-meta">opportunity code · monospace, tracked, uppercase</span>
          </div>
        </div>
      </div>

      <div className="spacer" />
      <div className="t-tiny" style={{ color: 'var(--ink-4)' }}>
        14 tokens · 8 components · 8 screens · 1 prototype
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// Main app
// ──────────────────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', t.dark ? 'dark' : 'light');
    if (t.accent) applyAccent(t.accent);
  }, [t.dark, t.accent]);

  return (
    <>
      <DesignCanvas>
        <DCSection id="hero" title="capture · by red5" subtitle="Trade-show lead capture. Designed for one hand, a noisy hall, and five-second decisions.">
          <DCArtboard id="proto" label="Interactive prototype" width={420} height={920}>
            <div style={{
              width: '100%', height: '100%',
              background: '#efece4',
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              padding: '20px 0',
            }}>
              <InteractivePhone dark={t.dark} />
            </div>
          </DCArtboard>

          <DCArtboard id="ds" label="Design system" width={620} height={820}>
            <DesignSystemCard />
          </DCArtboard>
        </DCSection>

        <DCSection id="capture-states" title="The capture flow" subtitle="Always returns to a fresh capture screen. Uploads happen in the background; never blocks new captures.">
          <DCArtboard id="s-ready" label="01 · Ready" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <CaptureReadyScreen />
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-live" label="02 · Live  ·  AI + match" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <CaptureLiveScreen elapsed={18} />
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-saved-toast" label="03 · Saved  ·  ambient toast" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <div style={{ position: 'relative', height: '100%' }}>
                <CaptureReadyScreen syncing={1} />
                <div className="toast-host">
                  <Toast
                    kind="accent"
                    icon={<Ic.Sparkle size={18} />}
                    title="Added to David Chen"
                    meta="ABC-742 · uploading in background"
                  />
                </div>
              </div>
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-offline-toast" label="04 · Offline  ·  saved toast" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <div style={{ position: 'relative', height: '100%' }}>
                <CaptureReadyScreen queue={3} />
                <div className="toast-host">
                  <Toast
                    kind="offline"
                    icon={<Ic.Cloudoff size={18} />}
                    title="Saved offline"
                    meta="3 queued · will sync on reconnect"
                    action="View queue"
                  />
                </div>
              </div>
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-outbox" label="05 · Outbox sheet" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <div style={{ position: 'relative', height: '100%' }}>
                <CaptureReadyScreen queue={2} syncing={1} />
                <QueueSheet onClose={() => {}} />
              </div>
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-target" label="06 · Updating existing lead" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <CaptureReadyScreen targetLead={{ name: 'David Chen', code: 'ABC-742' }} />
            </FrameWrap>
          </DCArtboard>
        </DCSection>

        <DCSection id="pickers" title="Switching & picking" subtitle="Bottom sheets keep the rep in flow — no nav stack, no lost context.">
          <DCArtboard id="s-switch" label="Show switcher" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <div style={{ position: 'relative', height: '100%' }}>
                <CaptureReadyScreen />
                <ShowSwitcherSheet currentCode="TS26" onClose={() => {}} />
              </div>
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-leadpicker" label="Pick existing lead" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <div style={{ position: 'relative', height: '100%' }}>
                <CaptureReadyScreen />
                <LeadPickerSheet onClose={() => {}} />
              </div>
            </FrameWrap>
          </DCArtboard>
        </DCSection>

        <DCSection id="surrounding" title="The rest of the app" subtitle="Sign in, the lead inbox, and the show admin.">
          <DCArtboard id="s-signin" label="Sign in" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <SignInScreen email="riley@yourcompany.com" sent={true} />
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-leads" label="Leads inbox" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <LeadsScreen />
            </FrameWrap>
          </DCArtboard>
          <DCArtboard id="s-team" label="Admin · Team & invites" width={410} height={840}>
            <FrameWrap dark={t.dark}>
              <TeamScreen />
            </FrameWrap>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakColor label="Accent" value={t.accent}
          options={['#D63E2C', '#0E0E0C', '#1F6FEB', '#0F8A5B', '#7A5AE0']}
          onChange={(v) => setTweak('accent', v)} />
        <TweakToggle label="Dark mode" value={t.dark}
          onChange={(v) => setTweak('dark', v)} />
      </TweaksPanel>
    </>
  );
}

function FrameWrap({ children, dark }) {
  return (
    <div style={{
      width: '100%', height: '100%',
      background: '#efece4',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <IOSDevice width={390} height={780} dark={dark}>
        <div style={{ height: '100%', background: 'var(--paper)' }}>
          {children}
        </div>
      </IOSDevice>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
