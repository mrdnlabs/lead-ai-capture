# Handoff: red5 / capture — UI redesign of AI Capture

## TL;DR

This is a **high-fidelity** redesign of the AI Capture PWA, branded under the publisher **red5**. It replaces the cluttered single-screen capture UI with a calm, voice-first, always-ready capture surface; introduces non-blocking background sync; adds manual lead selection; and ships a small admin surface for show team management.

The bundled HTML/CSS/JSX files are **design references** — running prototypes that show the intended look, behavior, and motion. Implement them inside the existing codebase (**Next.js 16 App Router + React 19 + Tailwind 4 + Serwist PWA**, per `docs/brief.md`), reusing the project's existing patterns. Don't ship the JSX in this bundle as-is.

---

## Fidelity

**High-fidelity.** Exact pixel values, colors, typography, motion, and copy are specified below and are visible in the prototype. Recreate pixel-perfectly using Tailwind 4 tokens (`@theme` block) — see § Design tokens.

---

## How to read this bundle

| File | What it is |
|---|---|
| `red5 capture.html` | Entry point. Open in a browser to see all states + an interactive prototype. |
| `styles.css` | All design tokens (colors, type, radii, shadows) + component classes. **Read this first** — it is the source of truth for tokens. |
| `ui.jsx` | Brand mark, queue pill, live pill, waveform, toast, icon set. |
| `screens.jsx` | One function per screen / sheet: `SignInScreen`, `CaptureReadyScreen`, `CaptureLiveScreen`, `LeadsScreen`, `ShowSwitcherSheet`, `LeadPickerSheet`, `QueueSheet`, `TeamScreen` (+ unused legacy: `HomeScreen`, `CaptureUploadingScreen`, `CaptureQueuedScreen`, `CaptureDoneScreen`). |
| `app.jsx` | Interactive prototype state machine + canvas assembly. **Use this to understand the capture flow's state transitions.** |
| `_demo_only/` | Scaffolds used to present the design (iPhone bezel, design canvas, tweaks panel). **Do not port these into the real app.** |

---

## What changed vs. the current app

| Old behavior | New behavior |
|---|---|
| `/` shows a "Where to next" list of routes | App lands directly on the capture screen for the rep's primary show (or last-used show). No intermediate home. |
| Capture screen has 6+ stacked cards with status checkboxes (AI assist, Simulate offline, Debug, etc.) | Capture screen has 3 zones: photo card, AI assist toggle, "Continue with existing lead". Dev toggles (`Simulate offline`, `Debug mode`) are removed from this surface — gate them behind `?dev=1` or an admin panel per the brief. |
| Tapping submit transitions to a full-screen `Uploading…` then `Capture uploaded` / `Saved locally` screen | Tapping stop drops back to a fresh capture screen immediately. A **bottom toast** confirms the result (~3.2s). Header pill is the persistent sync indicator. |
| Returning-lead matching is the only way to attach a capture to an existing lead | Auto-match is still the primary path; new "Continue with an existing lead" affordance lets the rep manually pick from a searchable lead picker sheet before recording. |
| Leads list is a plain grouped list | Card-based, with intent + missing-fields chips, confidence dot, captured-by initials, filter row. |
| Show context lives in the URL (`/s/[showCode]`) and the user is locked into one show per session | Show context lives in the URL **and** in a tappable header pill. Tapping the pill opens a switcher sheet — no nav stack push. |
| No admin surface for managing team membership | New `Admin → Team & invites` screen: QR invite + magic-link, role chips (`lead` / `rep`), expiry, members list, email-invite. |

---

## Design tokens (Tailwind 4 `@theme`)

Drop this in `app/globals.css` (or wherever you wire the Tailwind 4 theme). All values come from `styles.css` in this bundle — that file is the source of truth.

```css
@import 'tailwindcss';

@theme {
  /* ── Brand & ink ── */
  --color-ink:        #0E0E0C;
  --color-ink-2:      #2A2A26;
  --color-ink-3:      #57564F;
  --color-ink-4:      #8B897F;
  --color-ink-5:      #B7B5AB;
  --color-paper:      #FAFAF6;
  --color-paper-2:    #F2F1EB;
  --color-paper-3:    #E8E6DD;
  --color-surface:    #FFFFFF;
  --color-surface-2:  #F7F6F1;
  --color-rule:       rgb(14 14 12 / 0.08);
  --color-rule-2:     rgb(14 14 12 / 0.16);

  /* ── red5 accent ── */
  --color-accent:     oklch(0.58 0.21 25);   /* the red */
  --color-accent-2:   oklch(0.52 0.22 25);   /* hover */
  --color-accent-ink: #FFFFFF;                /* on-accent text */
  --color-accent-wash:oklch(0.96 0.04 25);   /* match banner bg */
  --color-accent-line:oklch(0.85 0.10 25);   /* match banner border */

  /* ── AI / live (cool blue, used sparingly) ── */
  --color-live:       oklch(0.62 0.10 230);
  --color-live-wash:  oklch(0.96 0.03 230);

  /* ── Status ── */
  --color-ok:         oklch(0.58 0.12 155);
  --color-ok-wash:    oklch(0.96 0.04 155);
  --color-warn:       oklch(0.68 0.15 70);
  --color-warn-wash:  oklch(0.96 0.05 80);

  /* ── Type ── */
  --font-sans:        'Hanken Grotesk', system-ui, -apple-system, sans-serif;
  --font-mono:        'JetBrains Mono', ui-monospace, Menlo, monospace;

  /* ── Radii ── */
  --radius-1:    8px;
  --radius-2:   12px;
  --radius-3:   16px;
  --radius-4:   24px;
  --radius-5:   32px;
  --radius-pill: 9999px;

  /* ── Shadows ── */
  --shadow-1:     0 1px 2px rgb(14 14 12 / 0.04), 0 1px 1px rgb(14 14 12 / 0.03);
  --shadow-2:     0 6px 24px rgb(14 14 12 / 0.08), 0 1px 2px rgb(14 14 12 / 0.04);
  --shadow-press: 0 24px 48px -16px rgb(214 62 44 / 0.45), 0 1px 0 rgb(255 255 255 / 0.4) inset;
}

/* Dark theme — apply via [data-theme="dark"] on <html> */
[data-theme="dark"] {
  --color-ink:        #F4F2EC;
  --color-ink-2:      #DAD7CE;
  --color-ink-3:      #9C9A91;
  --color-ink-4:      #6F6E66;
  --color-ink-5:      #44443E;
  --color-paper:      #0B0B0A;
  --color-paper-2:    #131311;
  --color-paper-3:    #1B1A17;
  --color-surface:    #161512;
  --color-surface-2:  #1E1D19;
  --color-rule:       rgb(244 242 236 / 0.10);
  --color-rule-2:     rgb(244 242 236 / 0.20);
  --color-accent:     oklch(0.65 0.20 25);
  --color-accent-2:   oklch(0.72 0.18 25);
  --color-accent-ink: #150807;
  --color-accent-wash:oklch(0.30 0.10 25);
  --color-accent-line:oklch(0.40 0.12 25);
  --color-live:       oklch(0.72 0.12 230);
  --color-live-wash:  oklch(0.28 0.06 230);
  --color-ok:         oklch(0.72 0.13 155);
  --color-ok-wash:    oklch(0.26 0.05 155);
  --color-warn:       oklch(0.78 0.15 70);
  --color-warn-wash:  oklch(0.28 0.05 70);
}
```

### Font loading

Add to `app/layout.tsx`:

```tsx
import { Hanken_Grotesk, JetBrains_Mono } from 'next/font/google';

const sans = Hanken_Grotesk({ subsets: ['latin'], weight: ['400','500','600','700'], variable: '--font-sans' });
const mono = JetBrains_Mono({ subsets: ['latin'], weight: ['400','500','600'], variable: '--font-mono' });

// ...
<body className={`${sans.variable} ${mono.variable} font-sans bg-paper text-ink antialiased`}>
```

### Spacing scale

Tailwind 4 defaults. Component-internal spacing uses the 4 / 8 / 12 / 16 / 20 / 24 / 32 ladder.

---

## Type system

| Token | Use | CSS |
|---|---|---|
| `t-title-lg` | Hero (Sign in, big confirmations) | `40px / 1.0 / -0.03em / 600` |
| `t-title` | Screen title (Leads, New capture) | `28px / 1.1 / -0.02em / 600` |
| `t-h2` | Sheet titles, section heads | `20px / 1.2 / -0.02em / 600` |
| `t-body` | Default copy | `15px / 1.45 / 400` |
| `t-meta` | Secondary copy | `13px / 1.4 / 400 · ink-3` |
| `t-tiny` | Tertiary copy | `11px / 1.4 / 400 · ink-3` |
| `t-eyebrow` | Above-title labels | `11px / 600 / 0.10em / uppercase · ink-3` |
| `op-code` | Opportunity codes (`ABC-742`) | mono / 500 / 0.10em / uppercase |
| `op-code-lg` | Hero code on confirmations | mono / 600 / 0.12em / uppercase / 32px |

**Always render opportunity codes in `--font-mono` with `letter-spacing: 0.10em` and `text-transform: uppercase`** — reps read them aloud, so the typography must support that.

---

## Screens

### 01 · Sign in (`/auth/signin`)
- Centered column. `BrandMark` top-left, "Published by red5" foot. Title "Ready when you are." with magic-link explainer. Email input (52px tall, rounded `--radius-3`). Primary button "Email me a link" with right-arrow icon. After submit, the button copy flips to "Link sent — check your inbox" and a small subtle card confirms the inbox.
- File: `screens.jsx` → `SignInScreen`

### 02 · Capture · Ready  ← **THE HOT PATH** ← **also the app's home**
Route: `/s/[showCode]/capture`, **but** also the destination of `/` (redirect to last-used or only show).

- **Top bar (h: ~80px counting status bar overlap)**
  - Left: **show pill** — a 36px-tall pill with the show's 22px swatch, name (max 220px, ellipsis), chevron-down icon. **Tap → opens `ShowSwitcherSheet`** (see § Sheets).
  - Right: **`QueuePill`** — three states:
    - `synced` (no count): translucent pill, green dot
    - `syncing N` (uploads in flight): live-wash pill, spinning ring, count
    - `N queued` (offline): warn-wash pill, cloud-off icon, count — **tap → opens `QueueSheet`**
- **Title**: eyebrow "New capture" / h1 "Ready when you are." OR "Adding to <name>" when a target lead is set.
- **Target lead chip (only when set)**: red5-accent-filled, rounded `--radius-3`. Layout: 36px user-icon avatar / column ("UPDATING · ABC-742" label + "David Chen" name) / close button. Tap close → clears target.
- **Photo card**: full-width, `--radius-3`, overflow hidden. Hero is a 16:10 placeholder labeled "BADGE PHOTO — TAP CAMERA" (use the existing camera/library file inputs from `CaptureRecorder.tsx`). Below the photo: two icon-buttons "Camera" / "Library", each `flex: 1` and 44px tall.
- **AI assist row**: a card with a 36×36 sparkle tile (filled black when on), title "AI assist" + tiny copy "Asks short gap-filling questions while you talk.", trailing toggle. Whole row is tappable. Border darkens to `--color-ink` when on.
- **Continue with existing lead** (only when no target set): a card-flat row with a user avatar tile + title "Continue with an existing lead" / subtitle "Skip the match — pick a lead to add this capture to." / right chevron. **Tap → opens `LeadPickerSheet`**.
- **Foot (sticky)**: the **capture button**. 96px tall, rounded `28px`, full-width, `--color-ink` background with `--color-paper` text. Left of label: a 28px red dot ring. Label "Tap to capture" or "Tap to add to ABC-742" when target is set. Below: t-tiny "Audio always saved · offline-ready".
- File: `screens.jsx` → `CaptureReadyScreen`. State props: `{ show, targetLead, queue, syncing, onStart, onSwitchShow, onPickLead, onClearTarget, onQueueTap }`.

### 03 · Capture · Live (recording, AI active)
- **Top bar**: show name as t-eyebrow (nowrap) + live timer pill (`● MM:SS`, pulsing red dot, tabular-nums).
- **Match banner** (when AI flagged a returning lead): accent-wash bg, sparkle tile, label "Returning lead" + bold "David Chen ABC-742", trailing "not them" ghost button. If `targetLead` is set instead of auto-match, hide this and show the target-chip variant (red, not wash).
- **AI status card**: small photo thumb (64px) + AI-reading pill + "4 of 6 fields captured" + ink progress bar.
- **Checklist card**: header "Captured" eyebrow. Each row is `grid: 18px 84px 1fr`: square checkbox (filled black when AI confirmed, amber for low-confidence) / field label / right-aligned value (ellipsis, nowrap).
- **Transcript card**: small live-wash eyebrow "Transcript", scrollable, 3 recent turns. `AI:` lines in `--color-ink`, `You:` lines in `--color-ink-2`. **Auto-scroll to bottom on new turns** (see `CaptureRecorder.tsx`'s existing `transcriptScrollRef` pattern).
- **Foot**: a row with two 44px icon-buttons (camera, library) + 44px-tall text input for "Type a note to the AI…". Below that: the **STOP & SAVE button** — `cap-btn.is-recording`, accent-red background, paper text, with a pulsing white ring animation around the 18px white square indicator.
- File: `screens.jsx` → `CaptureLiveScreen`.

### 04 · Leads inbox (`/s/[showCode]/leads`)
- Top bar: back arrow + queue pill + download icon-button (CSV export).
- Header: show name eyebrow / "Leads" title / "N · M missing fields" meta.
- Filter row: horizontally-scrollable chips. Default active: "All · N". Other chips: Today, Missing fields, High intent, Mine. Active state is filled black.
- Lead cards: name + company/title / right-aligned op-code. Below: intent chip (accent-wash for High, paper-2 for others) + missing-field chips (warn-wash). Footer row: confidence dot (ok = green, mid = warn, low = ink-5) + capture count + age + rep initials right-aligned.
- Foot: accent-button "+ New capture" (full-width, accent-red).
- File: `screens.jsx` → `LeadsScreen`.

### 05 · Admin · Team & invites (`/admin/shows/[showId]/team` — **new route**)
- Top bar: back arrow.
- Header: eyebrow `<show name> · admin` / "Team & invites" title / meta line "Reps need a sign-in (magic link) *and* a membership in this show to capture leads."
- **Invite link card** (dashed border): row with QR code (112×112) + scan/share copy + `link` text in mono (`capture.red5.co/join/<showCode>-<token>`) + role chip + expiry chip. Below: three sub-buttons (Copy link / Email link / New link).
- **Members list**: each row is a card with: avatar (warn-wash bg for `invited`), name + role-tag (`lead` filled black / `rep` muted / `invited` warn), email below (ellipsis), trailing more-icon.
- Foot: primary "+ Invite by email" button.
- File: `screens.jsx` → `TeamScreen`.

---

## Sheets (bottom-anchored, modal but lightweight)

All sheets share the same chrome: dark `rgb(14 14 12 / 0.32)` backdrop, paper-colored container with `border-top-left-radius / border-top-right-radius: 28px`, top handle (44×5 rounded bar), header with title + tiny copy + 32px close-x, scrollable body, optional foot.

Tap the backdrop to close (`onClick` on the host, with `stopPropagation` inside the sheet). Implement as portal modals to `body` so they layer cleanly above the route content.

### `ShowSwitcherSheet`
- Title: "Switch show".
- Body: each show is a `pick-row` (40px swatch + name with "today" live pill + meta line `code · dates · N leads`). Current is highlighted (`paper-2` bg) with a trailing `ok` pill showing `✓ current`. Others get a right chevron.
- Foot row: "Join a show" — QR icon tile + title/subtitle + chevron. Routes to the join flow (scan QR or paste invite link).

### `LeadPickerSheet`
- Title: "Add to existing" + tiny "This capture will be merged into the lead you pick."
- Below header: 44px-tall search input with magnifier icon, placeholder "Search name, company, or code…".
- Eyebrow "Recent · this booth".
- Body: each row is a `pick-row` (initial-avatar 36px + name + meta `company · code · missing X` + age right-aligned).
- On pick, the calling screen sets `targetLead = { name, code }` and closes the sheet.

### `QueueSheet` (outbox)
- Title: "Outbox" + tiny "Captures upload in the background. You can keep working."
- Body: each item is a `q-row` styled per status:
  - `uploading`: live-blue dot + code + name + age right + live-blue progress bar
  - `queued`: warn dot + meta "waiting · will upload when online"
  - `failed`: accent-red dot + meta "upload failed · tap retry" + retry button
- Foot tiny meta: "Auto-retry on reconnect · last sync 14s ago"

---

## Toasts (non-blocking confirmations)

`Toast` component (in `ui.jsx`). Positioned via `.toast-host` which is `position: absolute; left/right: 12px; bottom: 200px;` inside the screen container. Auto-dismiss after **3200ms** (tunable). Slide-up animation `0.24s ease-out` (translateY +12 → 0).

Three kinds:
| `kind` | Background | Foreground | Use |
|---|---|---|---|
| `accent` | `--color-accent-wash` | `--color-accent` | Merged into existing lead, post-reconnect "syncing 3" |
| `ok` | `--color-ink` | `--color-paper` | New lead saved |
| `offline` | `--color-warn-wash` | `--color-warn` | Saved offline, optional action button "View queue" |

Anatomy: icon (18px) / column (title 14/600 + meta 12/0.78 opacity) / optional ghost action button (28px tall, bordered with `currentColor`).

---

## State machine (capture flow)

The prototype's `InteractivePhone` (`app.jsx`) is the canonical model. Port the **state-machine intent** to your existing `CaptureRecorder.tsx` — don't duplicate it. The relevant additions:

```ts
type Route = 'ready' | 'live' | 'leads' | 'team';
type Sheet = null | 'switch' | 'pick' | 'queue';

const [route,      setRoute]      = useState<Route>('ready');
const [sheet,      setSheet]      = useState<Sheet>(null);
const [targetLead, setTargetLead] = useState<{name: string; code: string} | null>(null);
const [queue,      setQueue]      = useState<number>(0);   // in Dexie outbox
const [syncing,    setSyncing]    = useState<number>(0);   // in-flight POSTs
const [toast,      setToast]      = useState<ToastPayload | null>(null);
```

**Transitions to implement**:
- `record()`: `setRoute('live')`, start `MediaRecorder` + (online) realtime, reset timer.
- `stop()`: stop the recorder, then **immediately** `setRoute('ready')` and `setTargetLead(null)`. Pass the blob to a background upload (or enqueue in Dexie if offline). Show a toast. **Never block on the upload** — it must continue in the background while the user records the next lead.
- `onPickLead(lead)`: `setTargetLead({name, code: lead.opportunityCode})`, close sheet. The next `stop()` posts with `opportunityCode = targetLead.code` (the existing `queuedInput.opportunityCode` field in `CaptureRecorder.tsx` already supports this).
- `onSwitchShow(s)`: push `/s/<s.code>/capture` (no full reload — use the existing routing).
- On `online` event (or when `simulatedOffline` flips false): drain the Dexie outbox, increment `syncing`, then `syncing--` per resolved upload. Surface "Back online · syncing N" toast.

Important: the `Done` / `Queued` / `Uploading` **full-screen** routes from the prototype's earlier iterations are **deprecated**. Don't ship them. The toast + header pill replace them.

---

## Access control (membership model)

Per the brief and the user's question, here's the implementation intent. Most of this slots into the existing Supabase + Drizzle layer.

**Entities**
- `org` (existing): the tenant.
- `show` (existing): scoped to an org.
- `rep` (existing): person with magic-link auth.
- `show_membership` (existing under different name? confirm): `(rep_id, show_id, role)` where `role ∈ {'lead','rep'}`.
- `show_invite` (**new**): `(id, show_id, token, role, expires_at, created_by, max_uses, used_count, redeemed_at?)`. Token is 32 chars URL-safe.

**Flows**
1. **Invite link** (primary). An admin on `/admin/shows/[showId]/team` mints a `show_invite` row. The shareable URL is `https://capture.red5.co/join/<showCode>-<token>` (or your prod domain). The token is single-show, role-bound, expiring. Render it as text and QR.
2. When a logged-out rep opens the join URL:
   - Redirect to `/auth/signin?next=/join/<showCode>-<token>`.
   - After magic-link sign-in, on visiting `/join/...`, the server validates the token (not expired, not exhausted), creates a `show_membership` row, increments `used_count`, redirects to `/s/<showCode>/capture`.
3. When an already-logged-in rep opens the link, skip auth and just bind membership.
4. **Email invite**: same token, sent via the auth provider's transactional email. Tap → magic-link with `next=/join/...`. Same final binding.
5. **Self-join via show code** (already in brief R10): a known 5-char code (e.g. `K7Q3M`) acts as a publicly-redeemable token — same binding flow, but with a lower-trust short code instead of a long token. Reserve this for booth-floor speed.

**UI surface in this design**
- `TeamScreen` — see § Screens § 05.
- The "Join a show" affordance at the bottom of `ShowSwitcherSheet` opens a scan / paste flow (out of scope of this bundle — design TBD).

---

## Motion & micro-interactions

| Element | Motion |
|---|---|
| Capture button (idle) | `transform: scale(0.985)` on `:active`, `transition: transform 0.12s ease` |
| Capture button (recording) | Pulsing white ring around the indicator: `box-shadow: 0 0 0 0 → 0 0 0 24px rgb(255 255 255 / 0 → 0.55)`, 1.4s loop |
| `pill-live .dot` | 1.6s opacity pulse 1 ↔ 0.35 |
| Toast entry | translateY(12 → 0), 0.24s cubic-bezier(0.2,0.7,0.3,1) |
| Sheet entry | Implement slide-up from `translateY(100%) → 0`, 0.28s ease-out. (Not in this prototype — sheets render statically — but ship the live app with this transition.) |
| Show pill / Lead picker rows | `scale(0.99)` on `:active`, no hover (mobile) |
| QueuePill `syncing N` | 0.9s linear `rotate` on the inner ring |

---

## Iconography

Use **Lucide** (the brief explicitly raises this as the natural fit). The icons in `ui.jsx` are inline SVGs sized 20px at 1.6 stroke — exactly Lucide's defaults. Equivalent Lucide names:

| `Ic.*` | Lucide |
|---|---|
| `Mic` | `mic` |
| `Camera` | `camera` |
| `Image` | `image` |
| `Send` | `send` |
| `Check` | `check` |
| `X` | `x` |
| `Chev` | `chevron-right` |
| `Plus` | `plus` |
| `Search` | `search` |
| `Sparkle` | `sparkles` |
| `Cloudoff` | `cloud-off` |
| `Cloud` | `cloud` |
| `Download` | `download` |
| `QR` | `qr-code` |
| `Arrow` | `arrow-right` |
| `User` | `user` |
| `Mail` | `mail` |
| `Hash` | `hash` |
| `LeftArrow` | `arrow-left` |
| `More` | `more-horizontal` |

`emoji` glyphs (📷 📎) currently in `CaptureRecorder.tsx` — replace with `lucide-react` imports.

---

## Imagery & placeholders

- The `photo-thumb` placeholder (45° striped grey rectangle with mono-font caption) is **only** for design rendering. The real app uses the existing `URL.createObjectURL(file)` preview. Keep aspect-ratio `16/10` for the staging card.
- No marketing imagery is used. Brand is text-only ("capture · by red5").

---

## Accessibility checklist

- All tap targets ≥ 44×44 (per brief). Verify: icon-buttons in attachment toolbar, the sheet close-x, the role-tag stacks.
- Color contrast: `--color-ink` on `--color-paper` ≈ 16.5:1. `--color-accent` on white = 4.6:1 (AA for large text only — accent is reserved for buttons + status pills + headlines, not body copy). Don't use `--color-ink-3` on `--color-surface-2` for body text (3.7:1, fails AA).
- The capture button is the only `<button>` in the foot region — easy thumb target, no adjacent destructive control.
- Live transcript uses `role="log" aria-live="polite"` (not currently in the prototype — add when porting).
- Sheets need `role="dialog" aria-modal="true"` + focus trap + return focus to opener on close.

---

## Files in this bundle

```
design_handoff_red5_capture/
├── README.md                ← you are here
├── red5 capture.html        ← open this to see the whole design + interactive prototype
├── styles.css               ← canonical tokens + class styles
├── ui.jsx                   ← icons, brand mark, queue pill, toast, waveform
├── screens.jsx              ← every screen + sheet
├── app.jsx                  ← interactive prototype state machine
└── _demo_only/              ← scaffolds — do NOT port into the real app
    ├── ios-frame.jsx
    ├── design-canvas.jsx
    └── tweaks-panel.jsx
```

---

## Suggested implementation order

1. Wire the `@theme` block + fonts. Verify against `styles.css` colors with a quick swatch page.
2. Build the shared primitives in `components/ui/`: `Toast`, `QueuePill`, `LivePill`, `BrandMark`, `OpCode`. They're tiny and used everywhere.
3. Rebuild `CaptureRecorder.tsx`'s render to match § 02. Keep all its existing media + AI logic. Strip the dev toggles to a `?dev=1`-gated panel.
4. Replace the `'queued' | 'uploading' | 'done'` full-screen branches with the toast + immediate return to `ready`. Hook the toast to fire from the upload promise's resolve/reject.
5. Move the show name in the URL into a header pill that opens `ShowSwitcherSheet` (portal modal).
6. Add `LeadPickerSheet` — server action to fetch recent leads for `(show_id, capturedAt > now - 24h)`, plus a fuzzy search endpoint over name / company / code.
7. Add `QueueSheet` — read from Dexie's outbox, show in-flight + queued + failed.
8. Rebuild the Leads list per § 04.
9. New `/admin/shows/[showId]/team` route + invite-token plumbing (§ Access control).
10. Polish: motion, accessibility, dark mode (the tokens are already there — just gate via `data-theme` on `<html>` and add the OS-preference listener).

The original `docs/brief.md` § 6 priorities still apply — capture screen is the highest-ROI surface, leads list is second, the rest is polish.
